package org.goyal;

import org.junit.runner.RunWith;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/main/resources/features", glue={"org.goyal"})
public class AddClient {
	
	@Given("the user is on the Client Registration page")
	public void the_user_is_on_the_client_registration_page() {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new io.cucumber.java.PendingException();
		System.out.println("Step1: Given");
	}

	@When("the user enters First Name, Last Name, User Name, email, Address Line1, Contact Number")
	public void the_user_enters_first_name_last_name_user_name_email_address_line1_contact_number() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    System.out.println("Step2: When");
	}

	@And("user enters the password in the form")
	public void user_enters_the_password_in_the_form() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("Step3: And");
	}

	@And("the user click on the Add Client details button")
	public void the_user_click_on_the_add_client_details_button() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("Step4: And");
	}

	@Then("First Name, Last Name, User Name, email, Address Line1 and Contact Number is validated to be mandatory")
	public void first_name_last_name_user_name_email_address_line1_and_contact_number_is_validated_to_be_mandatory() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("Step5: Then");
	}

	@And("password is validated to be of minimum {int} chars including one upper case, one lower case and one numerical digit")
	public void password_is_validated_to_be_of_minimum_chars_including_one_upper_case_one_lower_case_and_one_numerical_digit(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("Step6: And");
	}

	@And("the user will be navigated to the Home Page")
	public void the_user_will_be_navigated_to_the_home_page() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("Step7: And");
	}

}
