package org.goyal;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/main/resources/features", glue={"org.goyal"})
public class ScheduleMeet {


@Given("the user is on the Schedule Meeting page")
public void the_user_is_on_the_schedule_meeting_page() {
    // Write code here that turns the phrase above into concrete actions
    //throw new io.cucumber.java.PendingException();
	System.out.println("Step1: Given");
}

@When("the user enters Meeting Title, Client Name,Date and Time, Password and Location")
public void the_user_enters_meeting_title_client_name_date_and_time_password_and_location() {
    // Write code here that turns the phrase above into concrete actions
    //throw new io.cucumber.java.PendingException();
	System.out.println("Step2: When");
}

@And("the user click on the Schedule Meeting button")
public void the_user_click_on_the_schedule_meeting_button() {
    // Write code here that turns the phrase above into concrete actions
    //throw new io.cucumber.java.PendingException();
	System.out.println("Step3: And");
}

@Then("Meeting Title, Meeting Date and Time is validated to be mandatory")
public void meeting_title_meeting_date_and_time_is_validated_to_be_mandatory() {
    // Write code here that turns the phrase above into concrete actions
    //throw new io.cucumber.java.PendingException();
	System.out.println("Step4: Then");
}

@And("Meeting date is validated to be in future and cannot be a post date")
public void meeting_date_is_validated_to_be_in_future_and_cannot_be_a_post_date() {
    // Write code here that turns the phrase above into concrete actions
 //   throw new io.cucumber.java.PendingException();
	System.out.println("Step5: And");
}

	
}
