import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ScheduleMeetComponent } from './schedule-meet/schedule-meet.component';
import { AddClientComponent } from './add-client/add-client.component';

const routes: Routes = [
  { path: 'add-client', component: AddClientComponent },
  { path: 'schedule-meet', component: ScheduleMeetComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
