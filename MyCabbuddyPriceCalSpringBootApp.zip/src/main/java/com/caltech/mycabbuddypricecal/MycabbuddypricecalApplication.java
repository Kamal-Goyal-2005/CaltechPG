package com.caltech.mycabbuddypricecal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MycabbuddypricecalApplication {

	public static void main(String[] args) {
		SpringApplication.run(MycabbuddypricecalApplication.class, args);
	}

}
