package com.caltech.mycabbuddypricecal;

import java.util.List;
import java.util.Random;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class PriceCalController {

	@GetMapping("/calculateprice/{pickuplocation}/{droplocation}")
	public Integer getmybookings(@PathVariable String pickuplocation,@PathVariable String droplocation) {
	
		Random random = new Random();
        int randomNumber = random.nextInt(300) + 1;
        
		if (pickuplocation.equals("Home")||pickuplocation.equals("Office")) {
			return 500 + randomNumber;
		}
		else {
			return 1000 + randomNumber;
		}
		
	}
}
