package com.caltech.cabbuddy;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.caltech.cabbuddy.pogo.Booking;
import com.caltech.cabbuddy.service.CabService;

@Controller
public class CabController {
	
	@Autowired
	CabService cabservice;
	
	Logger log=Logger.getAnonymousLogger();
	

	
/*	
	@RequestMapping("/BookCab")
	public ModelAndView insertOpr(HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	Booking b=new Booking();
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
	b.setPickupLocation(request.getParameter("pickupLocation"));
	b.setDropLocation(request.getParameter("dropLocation"));
	b.setCabType(request.getParameter("cabType"));
	log.info("Variables set of Booking");
	
	LocalDate travelDate = LocalDate.parse(request.getParameter("travelDate"), formatter);
	
	b.setTravelDate(travelDate);
	
	if (travelDate.compareTo(LocalDate.now())>=0) {
		b.setStatus("Open");
	} else {
		b.setStatus("Closed");
	}
	
	HttpSession session = request.getSession();
	String name = (String) session.getAttribute("name");
	b.setName(name);
	
	log.info("calling insert");
	
	if(cabservice.insert(b)!=null) {
		List<Booking> list=cabservice.getall();
		mv.setViewName("bookinglist.jsp");
		mv.addObject("list", list);
		log.info("setting view mame");
		mv.setViewName("displayAllBookings.jsp");
	}

		return mv;
		
	}
*/
	
	@PostMapping("/BookCab")
	public ModelAndView insertOpr(@RequestParam("pickupLocation") String pickupLocation,
			@RequestParam("dropLocation") String dropLocation,
			@RequestParam("cabType") String cabType,
			@RequestParam("travelDate") String travelDateStr,
			HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	Booking b=new Booking();
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
	b.setPickupLocation(pickupLocation);
	b.setDropLocation(dropLocation);
	b.setCabType(cabType);
	log.info("Variables set of Booking");
	
	LocalDate travelDate = LocalDate.parse(travelDateStr, formatter);
	
	b.setTravelDate(travelDate);
	
	if (travelDate.compareTo(LocalDate.now())>=0) {
		b.setStatus("Open");
	} else {
		b.setStatus("Closed");
	}
	
	HttpSession session = request.getSession();
	String name = (String) session.getAttribute("name");
	b.setName(name);
	
	log.info("calling insert");
	
	if(cabservice.insert(b)!=null) {
		List<Booking> list=cabservice.getall();
		mv.setViewName("bookinglist.jsp");
		mv.addObject("list", list);
		log.info("setting view mame");
		mv.setViewName("displayAllBookings.jsp");
	}

		return mv;
		
	}
	
	@RequestMapping("/getall")
	public ModelAndView getallOpr(HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	List<Booking> list=cabservice.getall();
	mv.setViewName("displayAllBookings.jsp");
	mv.addObject("list", list);
		return mv;
		
	}

	@RequestMapping("/getmybookings")
	public ModelAndView getmybookings(HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	HttpSession session = request.getSession();
	String name = (String) session.getAttribute("name");
	List<Booking> list=cabservice.findmybooking(name);
	mv.setViewName("displayMyBookings.jsp");
	mv.addObject("mylist", list);
		return mv;
		
	}
	
	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam("id") Integer id, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		Booking b = new Booking();
		String message = cabservice.deletebyId(id);
		List<Booking> list = cabservice.getall();
		mv.setViewName("displayAllBookings.jsp");
		mv.addObject("list", list);
		return mv;
	}
/*
	@RequestMapping("/update")
	public ModelAndView update(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		Booking b = new Booking();
		
		b.setBid(Integer.parseInt(request.getParameter("bid")));
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		b.setPickupLocation(request.getParameter("pickupLocation"));
		b.setDropLocation(request.getParameter("dropLocation"));
		b.setCabType(request.getParameter("cabType"));
		b.setStatus(request.getParameter("status"));
		log.info("Variables set of Booking");
		
		LocalDate travelDate = LocalDate.parse(request.getParameter("travelDate"), formatter);
		
		b.setTravelDate(travelDate);
		HttpSession session = request.getSession();
		String name = (String) session.getAttribute("name");
		b.setName(name);

		cabservice.update(b);
		List<Booking> list = cabservice.getall();
		mv.setViewName("displayAllBookings.jsp");
		mv.addObject("list", list);
		return mv;
	}
*/
	
	@PostMapping("/update")
	public ModelAndView update(@RequestParam("bid") String bid,
			@RequestParam("pickupLocation") String pickupLocation,
			@RequestParam("dropLocation") String dropLocation,
			@RequestParam("cabType") String cabType,
			@RequestParam("status") String status,
			@RequestParam("travelDate") String travelDateStr,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		Booking b = new Booking();
		
		b.setBid(Integer.parseInt(bid));
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		b.setPickupLocation(pickupLocation);
		b.setDropLocation(dropLocation);
		b.setCabType(cabType);
		b.setStatus(status);
		log.info("Variables set of Booking");
		
		LocalDate travelDate = LocalDate.parse(travelDateStr, formatter);
		
		b.setTravelDate(travelDate);
		HttpSession session = request.getSession();
		String name = (String) session.getAttribute("name");
		b.setName(name);

		cabservice.update(b);
		List<Booking> list = cabservice.getall();
		mv.setViewName("displayAllBookings.jsp");
		mv.addObject("list", list);
		return mv;
	}
}
