package com.caltech.cabbuddy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caltech.cabbuddy.pogo.Booking;
import com.caltech.cabbuddy.repo.CabRepository;


@Service
public class CabService {
    
	@Autowired
	CabRepository cabrepo;
	
	public Booking insert(Booking b) {
		return cabrepo.save(b);
	}
	
	public List<Booking> getall() {
		return cabrepo.findAll();
	}
	
	
	public String deletebyId(Integer id) {
		cabrepo.deleteById(id);
		return "Successfully deleted Cab Booking Id:"+id;
	}
	
	public Booking update(Booking b) {
		return cabrepo.save(b);
	}
	
	public List<Booking> findmybooking(String name) {
		return cabrepo.findmybooking(name);
	}
	
//	public List<Object[]> findAllBooking()
//	{
//		return cabrepo.findAllBooking();
//	}
}
