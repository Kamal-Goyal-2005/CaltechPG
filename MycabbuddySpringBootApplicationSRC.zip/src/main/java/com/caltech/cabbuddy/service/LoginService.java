package com.caltech.cabbuddy.service;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.caltech.cabbuddy.pogo.Login;
import com.caltech.cabbuddy.repo.LoginRepository;

@Service
public class LoginService {

	@Autowired
	LoginRepository loginservice;
	
	Logger log=Logger.getAnonymousLogger();
	
	@Autowired
    private PasswordEncoder passwordEncoder;
	
	public String register(Login login) {
		
		loginservice.save(login);
		return "User registered successfully";
	}
	
	public boolean validateuser(String name, String pwd) {
		
		String encodedpwd =  loginservice.validateuser(name);
		return (encodedpwd != null && passwordEncoder.matches(pwd, encodedpwd));
	}
	
	public boolean checkAdmin(String name, String pwd) {

		
        String encodedpwd =  loginservice.checkAdmin(name);
		return (encodedpwd != null && passwordEncoder.matches(pwd, encodedpwd));
	}
	
}
