package com.caltech.cabbuddy.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.caltech.cabbuddy.pogo.Login;

public interface LoginRepository extends JpaRepository<Login,Integer>{
	
	String sql = "select user.pwd from Login user where user.name=?1";
	
	
	String sql2 = "select user.pwd from Login user where user.name=?1 and user.name='admin'";

	@Query(sql)
	public String validateuser(String name);
	
	@Query(sql2)
	public String checkAdmin(String name);

}
