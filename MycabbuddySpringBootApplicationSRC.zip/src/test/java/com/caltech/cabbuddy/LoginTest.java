package com.caltech.cabbuddy;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.caltech.cabbuddy.pogo.Login;
import com.caltech.cabbuddy.service.LoginService;

@RunWith(SpringRunner.class) // need for junit4 and not for junit5
@SpringBootTest
public class LoginTest {
	
	@Autowired
	LoginService service;

	@Test
	public void loginuser() {
		assertTrue(service.validateuser("Kamal", "Kamal@123"));
	}
	
	@Test
	public void loginadminuser() {
		Login user = new Login();
		user.setName("admin");
		user.setPwd("Admin@123");
		assertTrue(service.checkAdmin(user.getName(), user.getPwd()));
	}
	
    public static String generateRandomNumber(int length) {
        StringBuilder randomNumber = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int digit = random.nextInt(10);
            randomNumber.append(digit);
        }

        return randomNumber.toString();
    }
    
    public static String generateRandomString(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder randomString = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            randomString.append(characters.charAt(index));
        }

        return randomString.toString();
    }


	@Test
	public void registeruser() {
		Login user = new Login();
		user.setName(generateRandomString(5));
		user.setPhone(generateRandomNumber(9));
		user.setPwd(generateRandomString(5));
		assertEquals("User registered successfully",service.register(user));
	}
}
