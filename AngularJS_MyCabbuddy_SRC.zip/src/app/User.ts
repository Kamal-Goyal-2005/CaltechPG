export class User {
name:string;
email:string;
experience:number;
domain:string;

}