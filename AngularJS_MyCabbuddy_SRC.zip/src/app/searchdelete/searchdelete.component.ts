import { Component,OnInit } from '@angular/core';
import { User } from '../User';
import { UserregistrationserviceService } from '../userregistrationservice.service';

@Component({
  selector: 'app-searchdelete',
  templateUrl: './searchdelete.component.html',
  styleUrls: ['./searchdelete.component.css']
})
export class SearchdeleteComponent implements OnInit {

  constructor(private service:UserregistrationserviceService){}
  users:any;
  email:any;

  ngOnInit(): void {
    let respo=this.service.getusers();
    respo.subscribe((data:any)=>this.users=data);
  }

public finduserbyemail(){
  let respo=this.service.getuserbyemail(this.email);
  respo.subscribe((data:any)=>this.users=data);
}

public deleteuser(id:number){
  let respo=this.service.deleteuser(id);
  respo.subscribe((data:any)=>this.users=data);
}
}


