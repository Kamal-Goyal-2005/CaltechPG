package com.caltech.mycabbuddy;






import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import static org.junit.Assert.assertTrue;

import java.util.Random;
import java.util.logging.Logger;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.caltech.mycabbuddy.pogo.Login;
import com.caltech.mycabbuddy.service.LoginService;

@RunWith(SpringRunner.class) // need for junit4 and not for junit5
@SpringBootTest
public class LoginTest {
	
	@Autowired
	LoginService service;
	
	Logger log=Logger.getAnonymousLogger();

	@Test
	public void loginuser() throws IOException {
		 String url = "http://localhost:8080/Login";
		 URL obj = new URL(url);

         // Open a connection
         HttpURLConnection con = (HttpURLConnection) obj.openConnection();

         // Set the request method to POST
         con.setRequestMethod("POST");

         // Set the content type to indicate that you are sending JSON data
         con.setRequestProperty("Content-Type", "application/json");

         // Enable input/output streams
         con.setDoOutput(true);
         con.setDoInput(true);

         // Create JSON data to be sent
         String jsonData = "{\"name\":\"admin\",\"phone\":\"544545545\",\"pwd\":\"Admin@123\"}";

         try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
             wr.writeBytes(jsonData);
             wr.flush();
         }

         // Get the response code
         int responseCode = con.getResponseCode();
         System.out.println("Response Code: " + responseCode);    
         log.info("Response Code: " + responseCode);
         try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) 
         {
             String inputLine;
             StringBuilder response = new StringBuilder();

             while ((inputLine = in.readLine()) != null) {
                 response.append(inputLine);
             }

             // Print the response
             System.out.println("Response: " + response.toString());
             log.info("Response: "+response.toString());
         }

      catch (Exception e) {
         e.printStackTrace();
     }         
		 
         assertNotNull(responseCode);
         
	}
	
	@Test
	public void loginadminuser() {
		Login user = new Login();
		user.setName("admin");
		user.setPwd("Admin@123");
		assertTrue(service.checkAdmin(user.getName(), user.getPwd()));
	}
	
    public static String generateRandomNumber(int length) {
        StringBuilder randomNumber = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int digit = random.nextInt(10);
            randomNumber.append(digit);
        }

        return randomNumber.toString();
    }
    
    public static String generateRandomString(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder randomString = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            randomString.append(characters.charAt(index));
        }

        return randomString.toString();
    }


	@Test
	public void registeruser() {
		Login user = new Login();
		user.setName(generateRandomString(5));
		user.setPhone(generateRandomNumber(9));
		user.setPwd(generateRandomString(5));
		assertEquals("User registered successfully",service.register(user));
	}
}
