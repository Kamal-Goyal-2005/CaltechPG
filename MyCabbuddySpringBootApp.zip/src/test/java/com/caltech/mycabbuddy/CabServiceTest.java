package com.caltech.mycabbuddy;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.caltech.mycabbuddy.pogo.Booking;
import com.caltech.mycabbuddy.service.CabService;

@RunWith(SpringRunner.class) // need for junit4 and not for junit5
@SpringBootTest
public class CabServiceTest {

	@Autowired
	CabService service;

    public static String generateRandomNumber(int length) {
        StringBuilder randomNumber = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int digit = random.nextInt(10);
            randomNumber.append(digit);
        }

        return randomNumber.toString();
    }
    
	@Test
	public void insertTest() {
		Booking b = new Booking();
		b.setBid(Integer.parseInt(generateRandomNumber(2)));
		b.setPickupLocation("Home");
		b.setDropLocation("Office");
		b.setCabType("Standard");
		b.setName("Kamal");
		b.setStatus("Open");
		b.setTravelDate(LocalDate.now());
		assertNotNull(service.insert(b));
		
		
	}
	
	@Test
	public void updateTest() {
		Booking b = new Booking();
		b.setBid(Integer.parseInt(generateRandomNumber(2)));
		b.setPickupLocation("Office");
		b.setDropLocation("Home");
		b.setCabType("Standard");
		b.setName("Kamal");
		b.setStatus("Open");
		b.setTravelDate(LocalDate.now());
		assertNotNull(service.update(b));
		
		
	}
	
	@Test
	public void getAllTest() {
		assertNotNull(service.getall());
	}
	
	@Test
	public void findMyBookingsTest() {
		assertNotNull(service.findmybooking("Kamal"));
	}
	
	@Test
	public void deleteByIdTest() {
		assertEquals("Successfully deleted Cab Booking Id:2",service.deletebyId(2));
	}
	
}
