package com.caltech.mycabbuddy;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.caltech.mycabbuddy.service.LoginService;

@RunWith(SpringRunner.class) // need for junit4 and not for junit5
@SpringBootTest
public class TestSample {

	@Autowired
	LoginService service;

	@Test
	public void loginuser() {
		assertTrue(service.validateuser("Kamal", "Kamal@123"));
	}

}
