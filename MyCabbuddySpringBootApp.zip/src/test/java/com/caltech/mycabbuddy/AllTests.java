package com.caltech.mycabbuddy;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({ CabServiceTest.class, LoginTest.class })
public class AllTests {

}
