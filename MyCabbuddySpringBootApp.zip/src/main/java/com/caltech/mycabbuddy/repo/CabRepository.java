package com.caltech.mycabbuddy.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.caltech.mycabbuddy.pogo.Booking;

public interface CabRepository extends JpaRepository<Booking,Integer>{

	
	String sql="select booking from Booking booking where name=?1";
	
	String sql2="select booking,user.phone from Booking booking, Login user where user.name=booking.name";
	
	@Query(sql)
	public List<Booking> findmybooking(String name);
	
	@Query(sql2)
	public List<Object[]> findAllBooking();
}
