package com.caltech.mycabbuddy.service;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caltech.mycabbuddy.pogo.Booking;
import com.caltech.mycabbuddy.repo.CabRepository;


@Service
public class CabService {
    
	@Autowired
	CabRepository cabrepo;
	
	Logger log=Logger.getAnonymousLogger();
	
	public Booking insert(Booking b) {
		log.info("Travel Date in Service:"+b.getTravelDate());
		return cabrepo.save(b);
	}
	
	public List<Booking> getall() {
		return cabrepo.findAll();
	}
	
	
	public String deletebyId(Integer id) {
		cabrepo.deleteById(id);
		return "Successfully deleted Cab Booking Id:"+id;
	}
	
	public Booking update(Booking b) {
		return cabrepo.save(b);
	}
	
	public List<Booking> findmybooking(String name) {
		return cabrepo.findmybooking(name);
	}
	
	public List<Object[]> findAllBooking()
	{
		return cabrepo.findAllBooking();
	}
	
	public Booking findBookingById(Integer id) {
			 return cabrepo.findById(id).orElse(new Booking());
	}
}
