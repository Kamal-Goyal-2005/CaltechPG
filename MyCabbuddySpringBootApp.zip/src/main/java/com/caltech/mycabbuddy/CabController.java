package com.caltech.mycabbuddy;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.caltech.mycabbuddy.pogo.Booking;
import com.caltech.mycabbuddy.service.CabService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CabController {
	
	@Autowired
	CabService cabservice;
	
	Logger log=Logger.getAnonymousLogger();
	
	
	@PostMapping("/BookCab")
	public String insertOpr(@RequestBody Booking booking,
			HttpServletRequest request,HttpServletResponse response) {
	String retStr=new String();

	
	log.info("Date:"+booking.getTravelDate());

	
	LocalDate tdate = booking.getTravelDate()!= null?booking.getTravelDate():LocalDate.now();
	
	if (tdate.compareTo(LocalDate.now())>=0) {
		booking.setStatus("Open");
	} else {
		booking.setStatus("Closed");
	}
	
	log.info("CabType:"+booking.getCabType());
	log.info("getPickupLocation:"+booking.getPickupLocation());
	log.info("getDropLocation:"+booking.getDropLocation());
	
	log.info("Date in Controller:"+booking.getTravelDate());
	
	if(cabservice.insert(booking)!=null) {
	//	List<Booking> list=cabservice.getall();
		retStr="Cab booked successfully";
	} else
	{
		retStr="Cab cannot be booked due to un-availability";
	}

		return retStr;
		
	}
	
	@GetMapping("/getallBookings")
	public List<Booking> getallOpr(HttpServletRequest request,HttpServletResponse response) {
	 return cabservice.getall();
		
	}

	@GetMapping("/getmybookings/{name}")
	public List<Booking> getmybookings(@PathVariable String name, HttpServletRequest request,HttpServletResponse response) {
	return cabservice.findmybooking(name);
		
	}
	
	@GetMapping("/getbookingbyid/{id}")
	public Booking findBookingById(@PathVariable Integer id) {
		return cabservice.findBookingById(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public List<Booking> delete(@PathVariable Integer id, HttpServletRequest request,
			HttpServletResponse response) {
		String message = cabservice.deletebyId(id);
		log.info("Delete Booking:"+message);
		return cabservice.getall();
	}
	
	@PostMapping("/update")
	public List<Booking> update(@RequestBody Booking booking,
			HttpServletRequest request, HttpServletResponse response) {

		log.info("Variables set of Booking");


		cabservice.update(booking);
		return cabservice.getall();
	}
}
