import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrls: ['./edit-client.component.css']
})
export class EditClientComponent implements OnInit {

  constructor(private http:HttpClient, private route:ActivatedRoute, private router:Router) {}

  id:number=0;
  first_name: string = '';
  last_name: string = '';
  user_name: string = '';
  email: string = '';
  pwd: string = '';
  Address_line1: string = '';
  Address_line2: string = '';
  Address_line3: string = '';
  contact_number: string = '';
  city: string = '';
  state: string = '';
  country: string = '';
  message: string = '';

  ngOnInit():void{
    this.route.paramMap.subscribe(params=>{
      const idParam=params.get('id');
      if(idParam!=null) {
        this.id=+idParam;
        this.fetchClient();
      } else {
        console.error("id is missing or null");
      }
    })
  }

  fetchClient(){
    this.http.get('http://localhost:3000/getClient/'+this.id).subscribe((response:any)=>
    {console.log(response.message);
      this.message=response.message;
      const client=response[0];
      this.first_name=client.first_name;
      this.last_name=client.last_name;
      this.user_name=client.user_name;
      this.email=client.email;
      this.Address_line1=client.Address_line1;
      this.Address_line2=client.Address_line2;
      this.Address_line3=client.Address_line3;
      this.city=client.city;
      this.state=client.state;
      this.country=client.country;
     },
    (error)=>{console.error('Error deleting client',error)}
    );
  }

  updateClient(){
    const client={
      id:this.id,
      first_name: this.first_name,
      last_name: this.last_name,
      user_name: this.user_name,
      email: this.email,
      pwd: this.pwd,
      Address_line1: this.Address_line1,
      Address_line2: this.Address_line2,
      Address_line3: this.Address_line3,
      contact_number: this.contact_number,
      city: this.city,
      state: this.state,
      country: this.country
    };
    
    this.http.put('http://localhost:3000/updateClient',client).subscribe((response:any)=>
    {console.log(response.message);
      this.message=response.message; this.router.navigate(['/view-client'])},
    (error)=>{console.error('Error updating client',error)}
    );
      }

}
