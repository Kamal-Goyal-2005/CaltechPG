import { formatDate } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-edit-meet',
  templateUrl: './edit-meet.component.html',
  styleUrls: ['./edit-meet.component.css']
})
export class EditMeetComponent implements OnInit {

  constructor(private http:HttpClient, private route:ActivatedRoute, private router:Router) {}

  minDate = new Date().toISOString().split('T')[0];  
  id:number=0;
  no_of_people:number=0;
  Title:string='';
  Meeting_Date:string='';
  Meeting_Time:string='';
  Duration:number=0;
  Meeting_password:string='';
  Location:string='';
  message:string='';


  ngOnInit():void{
    this.route.paramMap.subscribe(params=>{
      const idParam=params.get('id');
      if(idParam!=null) {
        this.id=+idParam;
        this.fetchMeeting();
      } else {
        console.error("id is missing or null");
      }
    })
  }

  fetchMeeting(){
    this.http.get('http://localhost:3000/getMeeting/'+this.id).subscribe((response:any)=>
    {console.log(response.message);
      this.message=response.message;
      const meeting=response[0];
      this.Title=meeting.Title;
      this.no_of_people=meeting.no_of_people;
      this.Meeting_Date= formatDate(meeting.Meeting_Date,'yyyy-MM-dd','en-US');
      this.Meeting_Time=meeting.Meeting_Time;
      this.Duration=meeting.Duration;
      this.Location=meeting.Location;
     },
    (error)=>{console.error('Error deleting meeting',error)}
    );
  }

  updateMeeting(){
    const meeting={
      id:this.id,
      no_of_people:this.no_of_people,
      Title:this.Title,
      Meeting_Date:this.Meeting_Date,
      Meeting_Time:this.Meeting_Time,
      Duration:this.Duration,
      Meeting_password:this.Meeting_password,
      Location:this.Location
    };
    
    this.http.put('http://localhost:3000/updateMeeting',meeting).subscribe((response:any)=>
    {console.log(response.message);
      this.message=response.message; this.router.navigate(['/view-meet'])},
    (error)=>{console.error('Error updating meeting',error)}
    );
      }

}
