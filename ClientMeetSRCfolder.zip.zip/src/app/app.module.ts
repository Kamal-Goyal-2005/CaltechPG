import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddClientComponent } from './add-client/add-client.component';
import { ScheduleMeetComponent } from './schedule-meet/schedule-meet.component';
import { FormsModule } from '@angular/forms';
import { RouterModule,Routes } from '@angular/router';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { ViewClientComponent } from './view-client/view-client.component';
import { EditClientComponent } from './edit-client/edit-client.component';
import { ViewMeetComponent } from './view-meet/view-meet.component';
import { EditMeetComponent } from './edit-meet/edit-meet.component';

const routes: Routes=[
  {path:'',redirectTo:'/view-client',pathMatch:'full'},
  {path:'add-client',component:AddClientComponent},
  {path:'view-client',component:ViewClientComponent},
  {path:'edit-client/:id',component:EditClientComponent},
  {path:'view-meet',component:ViewMeetComponent},
  {path:'schedule-meet',component:ScheduleMeetComponent},
  {path:'edit-meet/:id',component:EditMeetComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    AddClientComponent,
    ScheduleMeetComponent,
    ViewClientComponent,
    EditClientComponent,
    ViewMeetComponent,
    EditMeetComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
