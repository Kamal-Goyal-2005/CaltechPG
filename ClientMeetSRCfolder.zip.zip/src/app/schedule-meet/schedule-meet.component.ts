import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-schedule-meet',
  templateUrl: './schedule-meet.component.html',
  styleUrls: ['./schedule-meet.component.css']
})
export class ScheduleMeetComponent implements OnInit {
  minDate = new Date().toISOString().split('T')[0];  
  id:number=0;
  no_of_people:number=0;
  Title:string='';
  Meeting_Date:string='';
  Meeting_Time:string='';
  Duration:number=0;
  Meeting_password:string='';
  Location:string='';
  message:string='';

  constructor(private http: HttpClient) { }

  scheduleMeeting() {
    const meeting = {
      id:this.id,
      no_of_people:this.no_of_people,
      Title:this.Title,
      Meeting_Date:this.Meeting_Date,
      Meeting_Time:this.Meeting_Time,
      Duration:this.Duration,
      Meeting_password:this.Meeting_password,
      Location:this.Location
    };

 
    this.http.post('http://localhost:3000/scheduleMeeting', meeting).subscribe((response: any) => {
      console.log(response.message);
      this.message = response.message
    },
      (error) => { console.error('Error adding meeting', error) }
    );
  }

  password = 'password';
  show = false;

  ngOnInit() {
    this.password = 'password';
  }

  onClick() {
    if (this.password === 'password') {
      this.password = 'text';
      this.show = true;
    } else {
      this.password = 'password';
      this.show = false;
    }
  }

}
