import { Component,OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.css']
})
export class AddClientComponent implements OnInit {
  password = 'password';
  show = false;
  first_name: string = '';
  last_name: string = '';
  user_name: string = '';
  email: string = '';
  pwd: string = '';
  Address_line1: string = '';
  Address_line2: string = '';
  Address_line3: string = '';
  contact_number: string = '';
  city: string = '';
  state: string = '';
  country: string = '';
  message: string = '';

  constructor(private http: HttpClient) { }

  addClient() {
    const client = {
      first_name: this.first_name,
      last_name: this.last_name,
      user_name: this.user_name,
      email: this.email,
      pwd: this.pwd,
      Address_line1: this.Address_line1,
      Address_line2: this.Address_line2,
      Address_line3: this.Address_line3,
      contact_number: this.contact_number,
      city: this.city,
      state: this.state,
      country: this.country
    };

    console.log('first name '+this.first_name);

    this.http.post('http://localhost:3000/addClient', client).subscribe((response: any) => {
      console.log(response.message);
      this.message = response.message
    },
      (error) => { console.error('Error adding client', error) }
    );
  }

  ngOnInit() {
    this.password = 'password';
  }

  onClick() {
    if (this.password === 'password') {
      this.password = 'text';
      this.show = true;
    } else {
      this.password = 'password';
      this.show = false;
    }
  }

}
